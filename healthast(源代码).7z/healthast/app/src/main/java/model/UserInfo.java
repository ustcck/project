package model;

import java.io.Serializable;

@SuppressWarnings("serial")
public class UserInfo implements Serializable{
	
	public String account;
	public int type;
	private String username;
	private int age;
	private double weight;
	private double height;
	private int sex;
	private int walklength;
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public double getWeight() {
		return weight;
	}
	public void setWeight(double weight) {
		this.weight = weight;
	}
	public double getHeight() {
		return height;
	}
	public void setHeight(double height) {
		this.height = height;
	}
	public int getSex() {
		return sex;
	}
	public void setSex(int sex) {
		this.sex = sex;
	}
	public int getWalklength() {
		return walklength;
	}
	public void setWalklength(int walklength) {
		this.walklength = walklength;
	}
	
}
