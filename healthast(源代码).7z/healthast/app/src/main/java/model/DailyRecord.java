package model;

import java.io.Serializable;
import java.util.Calendar;

@SuppressWarnings("serial")
public class DailyRecord implements Serializable{

	private String account;
	private int year;
	private int month;
	private int day;
	private int userID;
	private int walknum;
	private double calorie;
	private double breakfast;
	private double lunch;
	private double supper;
	private double snack;
	private int suggest;

	public String getAccount() {
		return account;
	}
	public void setAccount(String account) {
		this.account = account;
	}
	
	public int getUserID() {
		return userID;
	}
	public void setUserID(int userID) {
		this.userID = userID;
	}
	public int getWalknum() {
		return walknum;
	}
	public void setWalknum(int walknum) {
		this.walknum = walknum;
	}
	public double getCalorie() {
		return calorie;
	}
	public void setCalorie(double calorie) {
		this.calorie = calorie;
	}
	public int getSuggest() {
		return suggest;
	}
	public void setSuggest(int suggest) {
		this.suggest = suggest;
	}
	public double getBreakfast() {
		return breakfast;
	}
	public void setBreakfast(double breakfast) {
		this.breakfast = breakfast;
	}
	public double getLunch() {
		return lunch;
	}
	public void setLunch(double lunch) {
		this.lunch = lunch;
	}
	public double getSupper() {
		return supper;
	}
	public void setSupper(double supper) {
		this.supper = supper;
	}
	public double getSnack() {
		return snack;
	}
	public void setSnack(double snack) {
		this.snack = snack;
	}
	public int getYear() {
		return year;
	}
	public void setYear(int year) {
		this.year = year;
	}
	public int getMonth() {
		return month;
	}
	public void setMonth(int month) {
		this.month = month;
	}
	public int getDay() {
		return day;
	}
	public void setDay(int day) {
		this.day = day;
	}
}
