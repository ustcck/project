package model;

import java.io.Serializable;

@SuppressWarnings("serial")
public class Food implements Serializable{

	private String foodname;
	private double calorie;          //卡路里
	private double carbohydrate;     //碳水化合物/g
	private double protein;          //蛋白质/g
	private double fat;              //脂肪/g
	private double vitaminA;         //维生素A/mg
	private double vitaminC;         //维生素C/mg
	private double Calcuim;          //钙/mg
	
	public String getFoodname() {
		return foodname;
	}
	public void setFoodname(String foodname) {
		this.foodname = foodname;
	}
	public double getCalorie() {
		return calorie;
	}
	public void setCalorie(double calorie) {
		this.calorie = calorie;
	}
	public double getCarbohydrate() {
		return carbohydrate;
	}
	public void setCarbohydrate(double carbohydrate) {
		this.carbohydrate = carbohydrate;
	}
	public double getProtein() {
		return protein;
	}
	public void setProtein(double protein) {
		this.protein = protein;
	}
	public double getFat() {
		return fat;
	}
	public void setFat(double fat) {
		this.fat = fat;
	}
	public double getVitaminA() {
		return vitaminA;
	}
	public void setVitaminA(double vitaminA) {
		this.vitaminA = vitaminA;
	}
	public double getVitaminC() {
		return vitaminC;
	}
	public void setVitaminC(double vitaminC) {
		this.vitaminC = vitaminC;
	}
	public double getCalcuim() {
		return Calcuim;
	}
	public void setCalcuim(double calcuim) {
		Calcuim = calcuim;
	}
}
