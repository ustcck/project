package business;

import android.content.Context;
import model.DailyRecord;

public class DailyRecordHandle extends Thread{

	public DailyRecord dr;
	public Context c;
	
	public DailyRecordHandle(DailyRecord dr, Context c){
		
		this.dr = dr;
		this.c = c;
	}
	@Override
	public void run() {
		
		ObjectTransfer.upLoad(dr, c, 
				"http://localhost:8080/HealthAssistantServer/DailyRecordHandle");
	}
}
