package business;

import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.io.Serializable;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

import org.apache.http.HttpStatus;

import com.example.healthassistantclient.DailyRecordShow;
import com.example.healthassistantclient.UserInfoShow;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Toast;

public class ObjectTransfer{
	
	static public void upLoad(Object o, Context c, String urlString) {
		URL url;
		byte[] b = new byte[1];
		try {
			url = new URL(urlString);
			HttpURLConnection hc = (HttpURLConnection) url.openConnection();
			hc.setRequestMethod("POST");
			hc.setDoOutput(true);
			OutputStream os = hc.getOutputStream();
			ObjectOutputStream oOs = new ObjectOutputStream(os);
			oOs.writeObject(o);
			os.close();
			//
			if (hc.getResponseCode() == HttpStatus.SC_OK) {
				InputStream is = hc.getInputStream();
				is.read(b);
				is.close();
			}

		} catch (MalformedURLException e) {
		} catch (IOException e) {
		}
		
		String s;

		switch ((int) b[0]) {
		case BusinessType.USERINFO_HANDLE_SUCCESS:
			s = "操作成功！";
			break;
		default:
			s = "操作失败！";
		}
		Toast.makeText(c, s, Toast.LENGTH_SHORT)
				.show();
	}
	
	static public void downLoad(Context c, String urlString, int type) {
		
		Object o;
		URL url;
		try {
			url = new URL(urlString);
			HttpURLConnection hc = (HttpURLConnection) url.openConnection();
			if (hc.getResponseCode() == HttpStatus.SC_OK) {
				InputStream is = hc.getInputStream();
				ObjectInputStream oIn = new ObjectInputStream(is);		
				o = oIn.readObject();
				is.close();
				Intent i;
				if(type == BusinessType.DOWNLOAD_USERINFO){
					i = new Intent(c, UserInfoShow.class);
				}else{
					i = new Intent(c, DailyRecordShow.class);
				}
				Bundle b = new Bundle();
				b.putSerializable("userinfo", (Serializable) o);
				i.putExtras(b);
				i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); 
				c.startActivity(i);
			}
			else
			{
				Toast.makeText(c, "网络异常！", Toast.LENGTH_SHORT)
					.show();
			}
		} catch (MalformedURLException e) {
		} catch (IOException e) {
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
	}
}
