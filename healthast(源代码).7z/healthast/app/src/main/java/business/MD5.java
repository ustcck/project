package business;

import java.math.BigInteger;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

public class MD5 {

    public static String getMD5(String in) {

        String algorithm = "";
        if (in == null) {
            return "null";
        }
        try {
            algorithm = System.getProperty("MD5.algorithm", "MD5");
        } catch (SecurityException se) {
        }
        MessageDigest md = null;
        try {
            md = MessageDigest.getInstance(algorithm);
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
        }
        byte buffer[] = in.getBytes();

        for (int i = 0; i < in.length(); i++) {
            md.update(buffer, 0, i);
        }
        byte bDigest[] = md.digest();
        BigInteger bigInteger = new BigInteger(bDigest);
        return (bigInteger.toString(16));
    }
}

