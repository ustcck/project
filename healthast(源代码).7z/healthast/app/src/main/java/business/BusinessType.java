package business;

final public class BusinessType {
	
	//Login
	final public static int LOGIN_SUCCESS = 1;
	final public static int LOGIN_NO_USER = 2;
	final public static int LOGIN_WRONG_PASSWORD = 3;
	
	//Register
	final public static int REGISTER_SUCCESS = 1;
	final public static int REGISTER_USER_EXIST = 2;
	final public static int REGISTER_FAIL = 3;
	
	//UserInfohandle
	final public static int USERINFO_ADD = 1;
	final public static int USERINFO_UPDATE = 2;
	final public static int USERINFO_HANDLE_SUCCESS = 3;
	final public static int USERINFO_HANDLE_FAIL = 4;
	
	//ObjectDownload
	final public static int DOWNLOAD_USERINFO = 1;
	final public static int DOWNLOAD_DAILYRECORD = 2;
}
