package business;

import android.content.Context;

public class UserInfoGet extends Thread{

	Context c;
	
	public UserInfoGet (Context c)
	{
		this.c = c;
	}
	@Override
	public void run() {	
		ObjectTransfer.downLoad(c, 
				"http://localhost:8080/HealthAssistantServer/UserInfoGet"
							+ "?ACCOUNT=" + CurrentUser.account,
							BusinessType.DOWNLOAD_USERINFO);
	}
}
