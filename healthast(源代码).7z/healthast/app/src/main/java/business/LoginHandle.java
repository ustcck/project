package business;

import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

import org.apache.http.HttpStatus;

import android.content.Context;
import android.widget.Toast;

public class LoginHandle extends Thread {
	public String username;
	public String password;
	public Context c;
    public LoginHandle(String u, String p, Context c)
    {
    	this.username = u;
    	this.password = MD5.getMD5(p);
    	this.c = c;
    }
	@Override
	public void run() {
		URL url;
		byte[] b = new byte[1];
		try {
			url = new URL(
					"http://localhost:8080/HealthAssistantServer/Login"
							+ "?ACCOUNT=" + username + "&PASSWORD="
							+ password);
			HttpURLConnection hc = (HttpURLConnection) url.openConnection();
			//
			if (hc.getResponseCode() == HttpStatus.SC_OK) {
				InputStream is = hc.getInputStream();
				is.read(b);
				is.close();
			}

		} catch (MalformedURLException e) {
		} catch (IOException e) {
		}
		String s;

		switch ((int) b[0]) {
		case BusinessType.LOGIN_SUCCESS:
			s = "登陆成功！";
			CurrentUser.account = username;
			break;
		case BusinessType.LOGIN_NO_USER:
			s = "用户名不存在！";
			break;
		case BusinessType.LOGIN_WRONG_PASSWORD:
			s = "密码错误！";
			break;
		default:
			s = "操作失败！";
		}
		Toast.makeText(c, s, Toast.LENGTH_SHORT)
				.show();
	}
}
