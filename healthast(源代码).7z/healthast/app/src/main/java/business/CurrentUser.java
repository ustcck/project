package business;

public final class CurrentUser {

	public static String account;
}
