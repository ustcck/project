package business;

import android.content.Context;

public class DailyRecordGet extends Thread {

    public Context c;

    public DailyRecordGet(Context c) {
        this.c = c;
    }

    @Override
    public void run() {
        ObjectTransfer.downLoad(c,
                "http://localhost:8080/HealthAssistantServer/DailyRecordGet"
                        + "?ACCOUNT=" + CurrentUser.account,
                BusinessType.DOWNLOAD_DAILYRECORD);
    }
}
