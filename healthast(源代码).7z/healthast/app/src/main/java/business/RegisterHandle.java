package business;

import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

import org.apache.http.HttpStatus;

import android.content.Context;
import android.widget.Toast;

public class RegisterHandle extends Thread{

	public String username;
	public String password;
	public Context c;
    public RegisterHandle(String u, String p, Context c)
    {
    	this.username = u;
    	this.password = MD5.getMD5(p);
    	this.c = c;
    }
	@Override
	public void run() {
		URL url;
		byte[] b = new byte[1];
		try {
			url = new URL(
					"http://localhost:8080/HealthAssistantServer/Register"
							+ "?ACCOUNT=" + username + "&PASSWORD="
							+ password);
			HttpURLConnection hc = (HttpURLConnection) url.openConnection();
			//
			if (hc.getResponseCode() == HttpStatus.SC_OK) {
				InputStream is = hc.getInputStream();
				is.read(b);
				is.close();
			}

		} catch (MalformedURLException e) {
		} catch (IOException e) {
		}
		String s;

		switch ((int) b[0]) {
		case BusinessType.REGISTER_SUCCESS:
			s = "注册成功！";
			break;
		case BusinessType.REGISTER_USER_EXIST:
			s = "用户名已存在！";
			break;
		default:
			s = "注册失败，请稍候再试！";
		}
		Toast.makeText(c, s, Toast.LENGTH_SHORT)
				.show();
	}
}
