package business;

import android.content.Context;
import model.UserInfo;

public class UserInfoHandle extends Thread{

	public UserInfo ui;
	public Context c;
	
	public UserInfoHandle(UserInfo ui, Context c, int type)
	{
		this.ui = ui;
		this.c = c;
		ui.account = CurrentUser.account;
		ui.type = type;
	}
	
	@Override
	public void run() {
		
		ObjectTransfer.upLoad(ui, c, 
				"http://localhost:8080/HealthAssistantServer/UserInfoHandle");
	}
}
