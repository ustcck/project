package com.example.healthassistantclient;

import model.UserInfo;
import sse.ustc.healthast.R;
import business.BusinessType;
import business.UserInfoHandle;
import android.app.Activity;
import android.os.Bundle;
import android.os.StrictMode;
import android.view.View;
import android.widget.Button;

public class UpdateUserInfo extends Activity {
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.addui);
		StrictMode.setThreadPolicy(new StrictMode.ThreadPolicy.Builder()
		.detectDiskReads().detectDiskWrites().detectNetwork()
		.penaltyLog().build());
		StrictMode.setVmPolicy(new StrictMode.VmPolicy.Builder()
		.detectLeakedSqlLiteObjects().detectLeakedClosableObjects()
		.penaltyLog().penaltyDeath().build());
		
		
	}
	
	private void setButtons() {
		// TODO Auto-generated method stub
		Button buttonUpui = (Button) findViewById(R.id.buttonaddui);
		
		buttonUpui.setOnClickListener(new View.OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				UserInfo ui = new UserInfo();
				ui.setUsername("haojie");
				ui.setAge(25);
				ui.setWeight(55.6);
				UserInfoHandle rg = new UserInfoHandle(ui, getApplicationContext(), BusinessType.USERINFO_UPDATE);
				rg.run();
			}
		});
	}
}
