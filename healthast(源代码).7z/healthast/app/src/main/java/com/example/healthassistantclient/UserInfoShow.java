package com.example.healthassistantclient;

import model.UserInfo;
import sse.ustc.healthast.R;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.EditText;

public class UserInfoShow extends Activity{

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		
		setContentView(R.layout.show);
		EditText ed = (EditText) findViewById(R.id.username);	
		Intent i = this.getIntent();
		UserInfo ui = (UserInfo) i.getSerializableExtra("userinfo");
		ed.setText(ui.getUsername());
	}
}
