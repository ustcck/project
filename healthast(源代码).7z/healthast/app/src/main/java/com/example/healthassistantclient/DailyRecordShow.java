package com.example.healthassistantclient;

import java.util.ArrayList;

import model.DailyRecord;
import sse.ustc.healthast.R;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;

public class DailyRecordShow extends Activity{

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		
		setContentView(R.layout.dailyrecordshow);
		TextView ed = (TextView) findViewById(R.id.dailyrecord);	
		Intent i = this.getIntent();
		ArrayList<DailyRecord> ldr = 
				(ArrayList<DailyRecord>) i.getSerializableExtra("userinfo");
		String s = new String();
		for(DailyRecord d : ldr){
			
			s = s + d.getYear() + "-" + String.valueOf(d.getMonth()+1) + "-" + d.getDay();
			s = s + ":Walknum = " + d.getWalknum() + "\n";
			Toast.makeText(this.getApplicationContext(), String.valueOf(d.getDay()), Toast.LENGTH_SHORT)
			.show();
		}
		
		ed.setText(s);
	}
}
