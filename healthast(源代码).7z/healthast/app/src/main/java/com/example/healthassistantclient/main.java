package com.example.healthassistantclient;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.StrictMode;
import android.widget.EditText;

public class main extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
	Intent i = new Intent(this, LoginAndRegister.class);
	startActivity(i);
	}
}
