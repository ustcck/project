package com.example.healthassistantclient;



import model.DailyRecord;
import sse.ustc.healthast.R;
import business.CurrentUser;
import business.DailyRecordGet;
import business.DailyRecordHandle;
import business.LoginHandle;
import business.RegisterHandle;
import business.UserInfoGet;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.StrictMode;
import android.view.Menu;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class LoginAndRegister extends Activity {

	private EditText usernameEdit;
	private EditText passwordEdit;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_login_and_register);

		StrictMode.setThreadPolicy(new StrictMode.ThreadPolicy.Builder()
				.detectDiskReads().detectDiskWrites().detectNetwork()
				.penaltyLog().build());
		StrictMode.setVmPolicy(new StrictMode.VmPolicy.Builder()
				.detectLeakedSqlLiteObjects().detectLeakedClosableObjects()
				.penaltyLog().penaltyDeath().build());
		usernameEdit = (EditText) findViewById(R.id.usernameEdit);
		passwordEdit = (EditText) findViewById(R.id.passwordEdit);
		setButtons();
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.login_and_register, menu);
		return true;
	}

	private void setButtons() {
		// TODO Auto-generated method stub
		Button loginButton = (Button) findViewById(R.id.loginButton);
		Button registerButton = (Button) findViewById(R.id.registerButton);
		Button adduiButton = (Button) findViewById(R.id.add_userinfo);
		Button updateuiButton = (Button) findViewById(R.id.update_userinfo);
		Button addDrButton = (Button) findViewById(R.id.add_dailyrecord);
		Button downUIButton = (Button) findViewById(R.id.downlaod_userInfo);
		Button downRecordButton = (Button) findViewById(R.id.download_dailyrecord);
		
		loginButton.setOnClickListener(new View.OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				String username = usernameEdit.getText().toString();
				String password = passwordEdit.getText().toString();
				LoginHandle rg = new LoginHandle(username, password, getApplicationContext());
				rg.run();
			}
		});
		
		registerButton.setOnClickListener(new View.OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				String username = usernameEdit.getText().toString();
				String password = passwordEdit.getText().toString();
				RegisterHandle rg = new RegisterHandle(username, password, getApplicationContext());
				rg.run();
			}
		});
		
		adduiButton.setOnClickListener(new View.OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				Intent intent = new Intent();
				intent.setClass(LoginAndRegister.this, AddUserInfo.class);
				startActivity(intent);
				
				
				
			}
		});
		
		updateuiButton.setOnClickListener(new View.OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				Intent intent = new Intent();
				intent.setClass(LoginAndRegister.this, UpdateUserInfo.class);
				startActivity(intent);
			}
		});
		
		addDrButton.setOnClickListener(new View.OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				DailyRecord dr = new DailyRecord();
				dr.setAccount(CurrentUser.account);
				dr.setYear(2015);
				dr.setMonth(4);
				dr.setDay(1);
				dr.setWalknum(156);
				DailyRecordHandle drh = new DailyRecordHandle(dr, getApplicationContext());
				drh.run();
			}
		});
		
		downUIButton.setOnClickListener(new View.OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				UserInfoGet uig = new UserInfoGet(getApplicationContext());
				uig.run();
				try {
					uig.join();
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		});
		
		downRecordButton.setOnClickListener(new View.OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				DailyRecordGet drg = new DailyRecordGet(getApplicationContext());
				drg.run();
				try {
					drg.join();
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		});
	}	
}
